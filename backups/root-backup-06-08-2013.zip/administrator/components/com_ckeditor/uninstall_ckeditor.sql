DELETE FROM #__extensions WHERE element = 'ckeditor' AND name = 'Editor - CKEditor';
-- DELETE FROM   #__components where name='CKEditor Component' AND `option`='com_ckeditor' ;