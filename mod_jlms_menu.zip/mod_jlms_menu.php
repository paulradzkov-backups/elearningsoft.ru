<?php

// no direct access
if (!defined( '_JEXEC' ) ) { die( 'Restricted access' ); }
if(!defined('_JLMS_EXEC')){ define('_JLMS_EXEC', 1); }
if(!defined( '_VALID_MOS' )){ //some of JoomlaLMS language files still contain 'VALID_MOS' check
	define( '_VALID_MOS', 1 );	
}

if(!defined('DS')){
	define('DS',DIRECTORY_SEPARATOR);
}

if (!defined( '_MOS_LMS_MENU_MODULE' )) {
	/** ensure that functions are declared only once */
	define( '_MOS_LMS_MENU_MODULE', 1 );
	/**
	* Vertically Indented Menu
	*/
	function JLMS_mosShowVIMenu(  &$params,&$menus ) {
		global $Itemid;
		$JLMS_CONFIG = & JLMSFactory::getConfig();
		
		require(JPATH_SITE.'/components/com_joomla_lms/languages/english/main.lang.php' );
		if ($JLMS_CONFIG->get('default_language', 'english') && $JLMS_CONFIG->get('default_language', 'english') != 'english') {
			require(JPATH_SITE.'/components/com_joomla_lms/languages/'.$JLMS_CONFIG->get('default_language', 'english').'/main.lang.php' );
		}
		require_once(JPATH_SITE."/components/com_joomla_lms/includes/libraries/lms.lib.language.php");
		JLMS_processLanguage($JLMS_LANGUAGE);
		
		$course_id = $JLMS_CONFIG->get('course_id');
		$menuclass = 'mainlevel'. $params->get( 'class_sfx' );
		$option = 'com_joomla_lms';
		$img =1;// $params->get( 'image' )
		$menulinks = $JLMS_CONFIG->get('jlms_menu');

		$task = JRequest::getVar( 'task', '', '', 'string' );
		$option = JRequest::getCmd('option');
		
		if ($course_id){
			echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">';
			foreach ($menulinks as $menu){
				if (isset($menu->disabled) && $menu->disabled) {
				} else {
					$id = '';
					if ($option == 'com_joomla_lms' && $menu->task == $task){
						$id = 'id="active_menu'. $params->get( 'class_sfx' ) .'"';
					}
					if(!$menu->is_separator && isset($menu->disabled) && !$menu->disabled && $menu->lang_var != '_JLMS_TOOLBAR_USER_OPTIONS'){
						if ($menu->help_task){
							$target = "target='_blank'";
						}
						echo'<tr><td>';
						$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
						if ($menu->lang_var && defined($menu->lang_var)) {
							$mitem_name = constant($menu->lang_var);
						}
						echo '<a href="'. $menu->menulink .'"  class="'. $menuclass .'" '.$menu->target. $id .'>'.$mitem_name.'</a>';
						echo '</td></tr>';
					}
				}
			}
			echo '</table>';
		} else {
			echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">';
			foreach ($menulinks as $menu){
				if (isset($menu->disabled) && $menu->disabled) {
				} else {
					$id = '';
					if ($option == 'com_joomla_lms' && $menu->task == $task){
						$id = 'id="active_menu'. $params->get( 'class_sfx' ) .'"';
					}
					if(!$menu->is_separator){
						echo'<tr><td>';
						$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
						if ($menu->lang_var && defined($menu->lang_var)) {
							$mitem_name = constant($menu->lang_var);
						}
						echo '<a href="'. $menu->menulink .'"  class="'. $menuclass .'" '.$menu->target. $id .'>'.$mitem_name.'</a>';
						echo '</td></tr>';
					}
				}
			}
			echo '</table>';
		}	
	}
	
	function JLMS_mosShowHFMenu(& $params, $style = 0)
	{
		global $Itemid, $JLMS_SESSION;
		$JLMS_CONFIG = & JLMSFactory::getConfig();
		
		$current_task = '';
		if(is_object($JLMS_SESSION)){
			$current_task = $JLMS_SESSION->get('jlms_task','');	
		}

		require(JPATH_SITE.'/components/com_joomla_lms/languages/english/main.lang.php' );
		if ($JLMS_CONFIG->get('default_language', 'english') && $JLMS_CONFIG->get('default_language', 'english') != 'english') {
			require(JPATH_SITE.'/components/com_joomla_lms/languages/'.$JLMS_CONFIG->get('default_language', 'english').'/main.lang.php' );
		}
		require_once(JPATH_SITE."/components/com_joomla_lms/includes/libraries/lms.lib.language.php");
		JLMS_processLanguage($JLMS_LANGUAGE);
		
		$course_id = $JLMS_CONFIG->get('course_id');
		$option = 'com_joomla_lms';
		$img =1;// $params->get( 'image' )
		$menulinks = $JLMS_CONFIG->get('jlms_menu');

		$task = JRequest::getVar( 'task', '', '', 'string' );
		$option = JRequest::getCmd('option');
		
		$menuclass = 'mainlevel'. $params->get( 'class_sfx' );
		$count_menus = 0;
		foreach ($menulinks as $menu) {
			if (isset($menu->disabled) && $menu->disabled) {
			} else {
				$count_menus ++;
			}
		}
		if (count( $menulinks ) && $count_menus) {
			switch ($style) {
				case 1:
					if ($course_id){
						echo '<ul id="'. $menuclass .'">';
						$can_be_active = true;
						foreach ($menulinks as $menu){
							if (isset($menu->disabled) && !is_null($menu->disabled) && $menu->disabled) {

							} else {
								if(!$menu->is_separator && isset($menu->lang_var) && $menu->lang_var != '_JLMS_TOOLBAR_USER_OPTIONS'){
									$is_active = false;
									if ($option == 'com_joomla_lms' && $menu->task && $can_be_active && ($menu->task != 'courses') && $menu->task == $current_task){
										$is_active = true;
										$can_be_active = false;
									} elseif ($option == 'com_joomla_lms' && $menu->task == $task && $can_be_active) {
										$is_active = true;
										$can_be_active = false;
									}
									if ($menu->help_task){
										$target = "target='_blank'";
									}
									$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
									if ($menu->lang_var && defined($menu->lang_var)) {
										$mitem_name = constant($menu->lang_var);
									}
									echo '<li><a '.($is_active ? 'id="active_menu'. $params->get( 'class_sfx' ) .'"':'').' class="'.$menuclass.'" href="'. $menu->menulink .'"  '.$menu->target.'><span>'.$mitem_name.'</span></a></li>';
								}
							}
						}
						echo '</ul>';
					} else {
						echo '<ul id="'. $menuclass .'">';
						$can_be_active = true;
						foreach ($menulinks as $menu){
							if (isset($menu->disabled) && $menu->disabled) {
							} else {
								if(!$menu->is_separator){
									$is_active = false;
									if ($option == 'com_joomla_lms' && $menu->task && $can_be_active && ($menu->task != 'courses') && $menu->task == $current_task){
										$is_active = true;
										$can_be_active = true;
									} elseif ($option == 'com_joomla_lms' && $menu->task == $task && $can_be_active ) {
										$is_active = true;
										$can_be_active = false;
									}
									$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
									if ($menu->lang_var && defined($menu->lang_var)) {
										$mitem_name = constant($menu->lang_var);
									}
									echo '<li><a '.($is_active ? 'id="active_menu'. $params->get( 'class_sfx' ) .'"':'').' class="'.$menuclass.'" href="'. $menu->menulink .'"  '.$menu->target.'><span>'.$mitem_name.'</span></a></li>';
								}
							}
						}
						echo '</ul>';
					}
				break;
				default:
					echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">';
					echo '<tr>';
					echo'<td nowrap="nowrap">';
					foreach ($menulinks as $menu){
						if (isset($menu->disabled) && $menu->disabled) {
						} else {
							$id = '';
							if ($option == 'com_joomla_lms' && $menu->task == $task){
								$id = 'id="active_menu'. $params->get( 'class_sfx' ) .'"';
							}
							if(!$menu->is_separator && $menu->lang_var != '_JLMS_TOOLBAR_USER_OPTIONS'){
								$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
								if ($menu->lang_var && defined($menu->lang_var)) {
									$mitem_name = constant($menu->lang_var);
								}
								echo '<a href="'. $menu->menulink .'"  class="'. $menuclass .'" '.$menu->target. $id .'>'.$mitem_name.'</a>';
								
							}
						}
					}
					echo '</td>';
					echo '</tr>';
					echo '</table>';
				break;
			}
		}
	}
	function JLMS_mosShowHF_listMenu(&$params){
		global $Itemid, $JLMS_SESSION;
		$JLMS_CONFIG = & JLMSFactory::getConfig();
		
		$current_task = '';
		if(is_object($JLMS_SESSION)){
			$current_task = $JLMS_SESSION->get('jlms_task','');	
		}
		
		require(JPATH_SITE.'/components/com_joomla_lms/languages/english/main.lang.php' );
		if ($JLMS_CONFIG->get('default_language', 'english') && $JLMS_CONFIG->get('default_language', 'english') != 'english') {
			require(JPATH_SITE.'/components/com_joomla_lms/languages/'.$JLMS_CONFIG->get('default_language', 'english').'/main.lang.php' );
		}
		require_once(JPATH_SITE."/components/com_joomla_lms/includes/libraries/lms.lib.language.php");
		JLMS_processLanguage($JLMS_LANGUAGE);
		
		$course_id = $JLMS_CONFIG->get('course_id');
		$option = 'com_joomla_lms';
		$img =1;// $params->get( 'image' )
		$menulinks = $JLMS_CONFIG->get('jlms_menu');

		$task = JRequest::getVar( 'task', '', '', 'string' );
		$option = JRequest::getCmd('option');
		
		$menuclass = 'mainlevel'. $params->get( 'class_sfx' );
		
		echo '<ul class="menu'. $params->get( 'class_sfx' ) .'">';
		$can_be_active = true;
		foreach ($menulinks as $menu){
			if (isset($menu->disabled) && $menu->disabled) {
			} else {
				$is_active = false;
				if(!$menu->is_separator && (!isset($menu->disabled) || !$menu->disabled) && $menu->lang_var != '_JLMS_TOOLBAR_USER_OPTIONS'){
					if ($option == 'com_joomla_lms' && $menu->task && $can_be_active && ($menu->task != 'courses') && $menu->task == $current_task){
						$is_active = true;
						$can_be_active = false;
					} elseif ($option == 'com_joomla_lms' && $menu->task == $task && $can_be_active){
						$is_active = true;
						$can_be_active = false;
					}
					$mitem_name = $JLMS_LANGUAGE[$menu->lang_var];
					if ($menu->lang_var && defined($menu->lang_var)) {
						$mitem_name = constant($menu->lang_var);
					}
					/*($is_active ? 'id="current"':'').*/
					$item_id = isset($menu->id) ? $menu->id : 0;
					echo '<li '.' class="'.($is_active ? 'active ':'').'item-'.$item_id.'"><a href="'. $menu->menulink .'"  '.$menu->target.'><span>'.$mitem_name.'</span></a></li>';
				}
			}
		}
		echo '</ul>';
	}
}

$params->def('class_sfx', '');
$params->def('menu_style', 'list');

global $Itemid;
$db = JFactory::getDBO();
$user = JFactory::getUser();
$user_id = $user->get('id');

if (!class_exists('JLMSFactory')) {
	require_once(JPATH_SITE."/components/com_joomla_lms/includes/classes/lms.factory.php");
}
$JLMS_CONFIG = & JLMSFactory::getConfig();

if (isset($user_id) && $user_id && $JLMS_CONFIG->get('lms_isonline', 0) && is_array($JLMS_CONFIG->get('jlms_menu', array())) && count($JLMS_CONFIG->get('jlms_menu', array())) ) {
	$menus = $JLMS_CONFIG->get('jlms_menu');
	switch ( $params->get( 'menu_style', 'list' ) ) {
		case 'horiz_flat':
			JLMS_mosShowHFMenu( $params, 0 );
			break;
		case 'list_flat':
			JLMS_mosShowHFMenu( $params, 1 );
			break;	
		case 'vert_indent':
			JLMS_mosShowVIMenu( $params, $menus );
			break;
		default:
			JLMS_mosShowHF_listMenu( $params );
			break;
	}
} else {
	$user_access = -1;
	if(isset($user_id) && $user_id){
		$user_access = 0;
	}
	
	$query	= "SELECT a.*"
	. "\n FROM `#__lms_menu` as a"
	. "\n WHERE 1"
	. "\n AND a.user_access = '".$user_access."'"
	. "\n AND a.published = 1"
	.($user_access == 0 ? "\n AND (lang_var = '_JLMS_TOOLBAR_COURSES' OR lang_var = '_JLMS_TOOLBAR_HOME' OR lang_var = '_JLMS_TOOLBAR_SUBSCRIPTIONS' OR lang_var = '_JLMS_TOOLBAR_LIBRARY')" : '')
	. "\n ORDER BY a.ordering "
	;
	$db->setQuery($query);
	$menus = $db->loadObjectList();
	
	$item_id = $JLMS_CONFIG->get('Itemid');
	$item_id = isset($item_id) && $item_id ? "&amp;Itemid=".$item_id : '';
	
	foreach ($menus as $menu){
		$option = 'com_joomla_lms';
		$item = new stdClass();
		$item->display_mod = 0;
		$item->task = $menu->task;
		$item->target = '';
		$item->help_task = 0;
		$item->user_options = 0;
		if ($menu->lang_var == '_JLMS_TOOLBAR_HELP' ){
			$item->help_task = 1;
			$item->target = " target='_blank' ";
		}
		if($menu->lang_var == '_JLMS_TOOLBAR_USER_OPTIONS' ){
			$item->user_options = 1;
		}
		$item->is_separator = $menu->is_separator;
		$item->image = $menu->image;
		$item->lang_var = $menu->lang_var;
		
		$task = '';
		if ($menu->task){
			$task = "&amp;task=".$menu->task;
		}

		if ($menu->lang_var == '_JLMS_TOOLBAR_COURSES' || $menu->lang_var == '_JLMS_TOOLBAR_HOME' || $menu->lang_var == '_JLMS_TOOLBAR_SUBSCRIPTIONS' || $menu->lang_var == '_JLMS_TOOLBAR_LIBRARY'){
			$ids = '';
		}else{
			$ids = "&amp;id=".$course_id;
		}
		if ($menu->lang_var == '_JLMS_TOOLBAR_HELP'){
			$item->menulink = 'http://www.joomlalms.com/index.php?option=com_lms_help&amp;Itemid=40&amp;task=view_by_task&amp;key=';
		} else {	
			if ($JLMS_CONFIG->get('under_ssl') && $JLMS_CONFIG->get('real_live_site')) {
				$item->menulink = $JLMS_CONFIG->get('real_live_site') . "/index.php?option=$option&amp;Itemid=$Itemid".$task.$ids;
			} else {
				$item->menulink = JRoute::_("index.php?option=com_joomla_lms".$task.$ids.$item_id);
			}
		}
		if ($menu->lang_var == '_JLMS_TOOLBAR_GQP_PARENT'){
			$item->menulink = JRoute::_("index.php?option=$option&amp;task=quizzes&amp;page=setup_gqp&amp;Itemid=$Itemid");
		}
		if ($menu->lang_var == '_JLMS_TOOLBAR_CEO_PARENT'){
			if ($user_parent) {
				$row[] = $item;
			}
		} else {
			$row[] = $item;
		}
	}
	
	$JLMS_CONFIG->set('jlms_menu', $row);
	$JLMS_CONFIG->set('course_id', 0);

	switch ( $params->get( 'menu_style', 'list' ) ) {
		case 'horiz_flat':
			JLMS_mosShowHFMenu( $params, 0 );
			break;
		case 'list_flat':
			JLMS_mosShowHFMenu( $params, 1 );
			break;	
		case 'vert_indent':
			JLMS_mosShowVIMenu( $params, $menus );
			break;
		default:
			JLMS_mosShowHF_listMenu( $params );
			break;
	}
}
?>