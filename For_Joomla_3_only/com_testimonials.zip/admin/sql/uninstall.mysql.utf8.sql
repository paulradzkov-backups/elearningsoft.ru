-- --------------------------------------------------------
-- Uninstall sql
-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__tm_testimonials`;
DROP TABLE IF EXISTS `#__tm_rating`;
DROP TABLE IF EXISTS `#__tm_testimonials_conformity`;
DROP TABLE IF EXISTS `#__tm_testimonials_custom`;
DROP TABLE IF EXISTS `#__tm_testimonials_items_fields`;
DROP TABLE IF EXISTS `#__tm_testimonials_settings`;
DROP TABLE IF EXISTS `#__tm_testimonials_tags`;
DROP TABLE IF EXISTS `#__tm_testimonials_tag_assign`;
DROP TABLE IF EXISTS `#__tm_testimonials_templates`;
DROP TABLE IF EXISTS `#__tm_testimonials_dashboard_items`;