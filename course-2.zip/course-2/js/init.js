﻿function jlms_courses_local_init() {
	var dummy = 0;
}