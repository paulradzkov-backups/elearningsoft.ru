/* Copyright (C) YOOtheme GmbH, YOOtheme Proprietary Use License (http://www.yootheme.com/license) */

(function(){$widgetkit.lazyloaders.googlemaps=function(a,b){$widgetkit.load(WIDGETKIT_URL+"/widgets/map/js/map.js").done(function(){a.googlemaps(b)})}})(jQuery);
